1:"$Sreact.fragment"
2:I[78616,[],"ClientSegmentRoot"]
3:I[3696,["8320","static/chunks/41ade5dc-716d85a2757e44a6.js","8500","static/chunks/8500-f62a38ff68ab7f42.js","450","static/chunks/450-d1d0cd0e0b09886c.js","1822","static/chunks/1822-7f23c8567c34582f.js","2788","static/chunks/app/(main)/admin/layout-35293ab83de070c3.js"],"default"]
4:I[57121,[],""]
5:I[74581,[],""]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"Component":"$3","slots":{"children":["$","$L4",null,{"parallelRouterKey":"children","template":["$","$L5",null,{}]}]},"serverProvidedParams":{"params":{},"promises":["$@6"]}}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"A9wgXyn6vrunfZ98_FEsP"}
6:"$0:rsc:props:children:1:props:serverProvidedParams:params"
