:HL["/_next/static/media/e4af272ccee01ff0-s.p.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/css/7b736202f0b1dbfd.css","style"]
:HL["/_next/static/css/dc442d3d5c330b46.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":28,"slots":{"children":{"name":"(main)","param":null,"prefetchHints":4,"slots":{"children":{"name":"admin","param":null,"prefetchHints":0,"slots":{"children":{"name":"referral","param":null,"prefetchHints":0,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}}}}}}}},"staleTime":300,"buildId":"A9wgXyn6vrunfZ98_FEsP"}
