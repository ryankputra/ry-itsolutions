1:I[57121,[],"LoadingBoundaryProvider"]
2:I[18910,["8910","static/chunks/8910-b19ebf5c06e2026a.js","2724","static/chunks/2724-66cf10ba47c69b6e.js","6698","static/chunks/app/(main)/loading-1d0a8540e6bd1f72.js"],"ModernAppLoader"]
3:"$Sreact.fragment"
4:I[57121,[],""]
5:I[74581,[],""]
6:[]
0:{"rsc":["$","$L1",null,{"loading":[["$","$L2","l",{}],[],[]],"children":["$","$3","c",{"children":[null,["$","$L4",null,{"parallelRouterKey":"children","template":["$","$L5",null,{}]}]]}]}],"isPartial":false,"staleTime":300,"varyParams":"$W6","buildId":"3MoJzOLS94FAH_t2SlH4a"}
